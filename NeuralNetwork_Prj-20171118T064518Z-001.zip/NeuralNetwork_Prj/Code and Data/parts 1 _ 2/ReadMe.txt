trnA contains the training pairs

tstA contains the validation pairs

The B and C versions of the files are just formatted verisions of these 2 files
to make running part II easier.