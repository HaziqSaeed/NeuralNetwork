Images divided into 64 training images (train folder) and 16 tests (validate folder).

folders subdivided into 00, 01, 02, and 03.
	00 contains avocados
	01 contains lemons
	02 contains limes
	03 contains oranges

Images sized to 128x128 pixels.